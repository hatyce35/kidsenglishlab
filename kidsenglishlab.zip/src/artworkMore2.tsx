import React from 'react';
import { ArtworkProps } from './artworkComponents';

const cursorClass = (interactive: boolean) =>
  interactive ? 'cursor-pointer hover:opacity-85 hover:stroke-amber-400 hover:stroke-[3px] transition-all' : '';

const getF = (parts: Record<string, string>, key: string, fallback: string) => parts[key] || fallback;

// 61. 🦌 DEER (4 Letters)
export const DeerColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Antlers */}
      <path d="M 85 70 L 60 30 M 70 45 L 85 35" stroke="#78350F" strokeWidth="4" strokeLinecap="round" />
      <path d="M 155 70 L 180 30 M 170 45 L 155 35" stroke="#78350F" strokeWidth="4" strokeLinecap="round" />
      {/* Ears */}
      <ellipse cx="60" cy="85" rx="18" ry="10" transform="rotate(-30 60 85)" fill={getF(parts, 'head', '#D97706')} stroke="#1E293B" strokeWidth="3.5" />
      <ellipse cx="180" cy="85" rx="18" ry="10" transform="rotate(30 180 85)" fill={getF(parts, 'head', '#D97706')} stroke="#1E293B" strokeWidth="3.5" />
      {/* Head */}
      <ellipse cx="120" cy="120" rx="52" ry="46" fill={getF(parts, 'head', '#D97706')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('head')} />
      {/* Spots */}
      <circle cx="95" cy="85" r="4" fill="#FFFFFF" />
      <circle cx="145" cy="85" r="4" fill="#FFFFFF" />
      <circle cx="120" cy="80" r="4" fill="#FFFFFF" />
      {/* Eyes */}
      <circle cx="92" cy="115" r="7.5" fill="#1E293B" />
      <circle cx="90" cy="112" r="2.5" fill="white" />
      <circle cx="148" cy="115" r="7.5" fill="#1E293B" />
      <circle cx="146" cy="112" r="2.5" fill="white" />
      {/* Snout */}
      <ellipse cx="120" cy="142" rx="22" ry="15" fill={getF(parts, 'snout', '#FEF3C7')} stroke="#1E293B" strokeWidth="3.5" className={cc} onClick={() => interactive && onPartClick?.('snout')} />
      <ellipse cx="120" cy="136" rx="6" ry="4" fill="#1E293B" />
      <ellipse cx="80" cy="132" rx="8" ry="5" fill={getF(parts, 'cheeks', '#FDA4AF')} />
      <ellipse cx="160" cy="132" rx="8" ry="5" fill={getF(parts, 'cheeks', '#FDA4AF')} />
    </g>
  );
};

// 62. 🦀 CRAB (4 Letters)
export const CrabColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Claws */}
      <path d="M 60 90 Q 30 50 50 35 Q 75 55 60 90" fill={getF(parts, 'claws', '#EF4444')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('claws')} />
      <path d="M 180 90 Q 210 50 190 35 Q 165 55 180 90" fill={getF(parts, 'claws', '#EF4444')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('claws')} />
      {/* Legs */}
      <path d="M 50 140 Q 25 150 25 170" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" fill="none" />
      <path d="M 60 160 Q 35 175 40 195" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" fill="none" />
      <path d="M 190 140 Q 215 150 215 170" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" fill="none" />
      <path d="M 180 160 Q 205 175 200 195" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" fill="none" />
      {/* Body */}
      <ellipse cx="120" cy="140" rx="60" ry="42" fill={getF(parts, 'body', '#EF4444')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('body')} />
      {/* Eyestalks */}
      <line x1="95" y1="105" x2="95" y2="85" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" />
      <line x1="145" y1="105" x2="145" y2="85" stroke="#1E293B" strokeWidth="4" strokeLinecap="round" />
      <circle cx="95" cy="80" r="10" fill="#FFFFFF" stroke="#1E293B" strokeWidth="3.5" />
      <circle cx="95" cy="80" r="4.5" fill="#1E293B" />
      <circle cx="145" cy="80" r="10" fill="#FFFFFF" stroke="#1E293B" strokeWidth="3.5" />
      <circle cx="145" cy="80" r="4.5" fill="#1E293B" />
      {/* Smile */}
      <path d="M 105 145 Q 120 160 135 145" stroke="#FFFFFF" strokeWidth="4" strokeLinecap="round" fill="none" />
      <ellipse cx="85" cy="145" rx="7" ry="4.5" fill={getF(parts, 'cheeks', '#FDA4AF')} />
      <ellipse cx="155" cy="145" rx="7" ry="4.5" fill={getF(parts, 'cheeks', '#FDA4AF')} />
    </g>
  );
};

// 63. 🐺 WOLF (4 Letters)
export const WolfColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Ears */}
      <polygon points="50,85 75,30 100,75" fill={getF(parts, 'head', '#64748B')} stroke="#1E293B" strokeWidth="4.5" />
      <polygon points="62,75 75,45 88,75" fill={getF(parts, 'earsInner', '#CBD5E1')} />
      <polygon points="140,75 165,30 190,85" fill={getF(parts, 'head', '#64748B')} stroke="#1E293B" strokeWidth="4.5" />
      <polygon points="152,75 165,45 178,75" fill={getF(parts, 'earsInner', '#CBD5E1')} />
      {/* Head */}
      <circle cx="120" cy="120" r="60" fill={getF(parts, 'head', '#64748B')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('head')} />
      {/* Muzzle */}
      <polygon points="90,125 150,125 120,165" fill={getF(parts, 'snout', '#E2E8F0')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('snout')} />
      <circle cx="120" cy="155" r="7" fill="#1E293B" />
      {/* Eyes */}
      <circle cx="95" cy="108" r="7" fill="#FBBF24" stroke="#1E293B" strokeWidth="2" />
      <circle cx="95" cy="108" r="3.5" fill="#1E293B" />
      <circle cx="145" cy="108" r="7" fill="#FBBF24" stroke="#1E293B" strokeWidth="2" />
      <circle cx="145" cy="108" r="3.5" fill="#1E293B" />
    </g>
  );
};

// 64. 🐐 GOAT (4 Letters)
export const GoatColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Horns */}
      <path d="M 85 75 Q 65 30 50 40" stroke="#78350F" strokeWidth="7" strokeLinecap="round" fill="none" />
      <path d="M 155 75 Q 175 30 190 40" stroke="#78350F" strokeWidth="7" strokeLinecap="round" fill="none" />
      {/* Head */}
      <ellipse cx="120" cy="120" rx="50" ry="46" fill={getF(parts, 'head', '#F1F5F9')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('head')} />
      {/* Beard */}
      <polygon points="110,165 130,165 120,195" fill={getF(parts, 'beard', '#E2E8F0')} stroke="#1E293B" strokeWidth="3" className={cc} onClick={() => interactive && onPartClick?.('beard')} />
      {/* Snout */}
      <ellipse cx="120" cy="148" rx="26" ry="18" fill={getF(parts, 'snout', '#FDA4AF')} stroke="#1E293B" strokeWidth="3.5" />
      <ellipse cx="112" cy="146" rx="3.5" ry="5" fill="#1E293B" />
      <ellipse cx="128" cy="146" rx="3.5" ry="5" fill="#1E293B" />
      {/* Eyes */}
      <circle cx="92" cy="110" r="7" fill="#1E293B" />
      <circle cx="90" cy="107" r="2.5" fill="white" />
      <circle cx="148" cy="110" r="7" fill="#1E293B" />
      <circle cx="146" cy="107" r="2.5" fill="white" />
    </g>
  );
};

// 65. 🦭 SEAL (4 Letters)
export const SealColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Flippers */}
      <ellipse cx="65" cy="165" rx="28" ry="14" transform="rotate(25 65 165)" fill={getF(parts, 'flippers', '#38BDF8')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('flippers')} />
      <ellipse cx="175" cy="165" rx="28" ry="14" transform="rotate(-25 175 165)" fill={getF(parts, 'flippers', '#38BDF8')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('flippers')} />
      {/* Body */}
      <ellipse cx="120" cy="130" rx="55" ry="50" fill={getF(parts, 'body', '#38BDF8')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('body')} />
      {/* Snout */}
      <ellipse cx="120" cy="145" rx="26" ry="18" fill={getF(parts, 'snout', '#FFFFFF')} stroke="#1E293B" strokeWidth="3.5" className={cc} onClick={() => interactive && onPartClick?.('snout')} />
      <circle cx="120" cy="138" r="6" fill="#1E293B" />
      <path d="M 112 148 Q 120 156 128 148" stroke="#1E293B" strokeWidth="3" strokeLinecap="round" fill="none" />
      {/* Whiskers */}
      <line x1="85" y1="145" x2="70" y2="142" stroke="#1E293B" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="155" y1="145" x2="170" y2="142" stroke="#1E293B" strokeWidth="2.5" strokeLinecap="round" />
      {/* Big Eyes */}
      <circle cx="95" cy="115" r="8" fill="#1E293B" />
      <circle cx="92" cy="112" r="3" fill="white" />
      <circle cx="145" cy="115" r="8" fill="#1E293B" />
      <circle cx="142" cy="112" r="3" fill="white" />
    </g>
  );
};

// 66. 🍐 PEAR (4 Letters)
export const PearColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Leaf & Stem */}
      <path d="M 120 60 Q 120 30 135 25" stroke="#78350F" strokeWidth="5" strokeLinecap="round" fill="none" />
      <ellipse cx="145" cy="45" rx="16" ry="9" transform="rotate(-20 145 45)" fill={getF(parts, 'leaf', '#22C55E')} stroke="#1E293B" strokeWidth="3" className={cc} onClick={() => interactive && onPartClick?.('leaf')} />
      {/* Pear Body */}
      <path d="M 120 60 C 85 60, 80 110, 60 140 C 45 170, 70 215, 120 215 C 170 215, 195 170, 180 140 C 160 110, 155 60, 120 60 Z" fill={getF(parts, 'body', '#A3E635')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('body')} />
      {/* Face */}
      <circle cx="98" cy="145" r="6.5" fill="#1E293B" />
      <circle cx="96" cy="142" r="2" fill="white" />
      <circle cx="142" cy="145" r="6.5" fill="#1E293B" />
      <circle cx="140" cy="142" r="2" fill="white" />
      <ellipse cx="82" cy="155" rx="7" ry="4.5" fill={getF(parts, 'cheeks', '#FB7185')} />
      <ellipse cx="158" cy="155" rx="7" ry="4.5" fill={getF(parts, 'cheeks', '#FB7185')} />
      <path d="M 112 158 Q 120 168 128 158" stroke="#1E293B" strokeWidth="3" strokeLinecap="round" fill="none" />
    </g>
  );
};

// 67. 🥝 KIWI (4 Letters)
export const KiwiColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Outer Skin */}
      <circle cx="120" cy="120" r="70" fill={getF(parts, 'skin', '#78350F')} stroke="#1E293B" strokeWidth="5" className={cc} onClick={() => interactive && onPartClick?.('skin')} />
      {/* Green Flesh */}
      <circle cx="120" cy="120" r="58" fill={getF(parts, 'flesh', '#84CC16')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('flesh')} />
      {/* White Core */}
      <ellipse cx="120" cy="120" rx="22" ry="18" fill={getF(parts, 'core', '#ECFCCB')} />
      {/* Seeds */}
      <circle cx="120" cy="90" r="3" fill="#1E293B" />
      <circle cx="142" cy="98" r="3" fill="#1E293B" />
      <circle cx="150" cy="120" r="3" fill="#1E293B" />
      <circle cx="142" cy="142" r="3" fill="#1E293B" />
      <circle cx="120" cy="150" r="3" fill="#1E293B" />
      <circle cx="98" cy="142" r="3" fill="#1E293B" />
      <circle cx="90" cy="120" r="3" fill="#1E293B" />
      <circle cx="98" cy="98" r="3" fill="#1E293B" />
    </g>
  );
};

// 68. 🌹 ROSE (4 Letters)
export const RoseColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Stem & Leaves */}
      <path d="M 120 140 Q 120 190 120 215" stroke="#15803D" strokeWidth="5" strokeLinecap="round" />
      <ellipse cx="95" cy="175" rx="16" ry="9" transform="rotate(-30 95 175)" fill={getF(parts, 'leaves', '#22C55E')} stroke="#1E293B" strokeWidth="3" className={cc} onClick={() => interactive && onPartClick?.('leaves')} />
      <ellipse cx="145" cy="185" rx="16" ry="9" transform="rotate(30 145 185)" fill={getF(parts, 'leaves', '#22C55E')} stroke="#1E293B" strokeWidth="3" className={cc} onClick={() => interactive && onPartClick?.('leaves')} />
      {/* Rose Petals */}
      <circle cx="120" cy="95" r="50" fill={getF(parts, 'petals', '#E11D48')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('petals')} />
      <path d="M 95 90 C 95 65 145 65 145 90 C 145 115 95 115 95 90 Z" fill={getF(parts, 'center', '#BE123C')} stroke="#1E293B" strokeWidth="3.5" />
      <circle cx="120" cy="90" r="14" fill="#881337" />
    </g>
  );
};

// 69. ⛵ BOAT (4 Letters)
export const BoatColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Waves */}
      <path d="M 30 190 Q 60 175 90 190 T 150 190 T 210 190" stroke="#0284C7" strokeWidth="5" strokeLinecap="round" fill="none" />
      {/* Boat Hull */}
      <path d="M 45 150 L 195 150 L 175 185 L 65 185 Z" fill={getF(parts, 'hull', '#F97316')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('hull')} />
      {/* Mast */}
      <line x1="120" y1="50" x2="120" y2="150" stroke="#78350F" strokeWidth="5" strokeLinecap="round" />
      {/* Sail */}
      <polygon points="125,55 185,135 125,135" fill={getF(parts, 'sail', '#FFFFFF')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('sail')} />
      <polygon points="115,70 65,135 115,135" fill={getF(parts, 'sail', '#38BDF8')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('sail')} />
    </g>
  );
};

// 70. 🔔 BELL (4 Letters)
export const BellColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Top Loop */}
      <circle cx="120" cy="55" r="16" fill="none" stroke="#1E293B" strokeWidth="5" />
      {/* Clapper */}
      <circle cx="120" cy="185" r="15" fill={getF(parts, 'clapper', '#D97706')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('clapper')} />
      {/* Bell Body */}
      <path d="M 120 65 C 80 65, 70 140, 50 170 L 190 170 C 170 140, 160 65, 120 65 Z" fill={getF(parts, 'body', '#FBBF24')} stroke="#1E293B" strokeWidth="5" className={cc} onClick={() => interactive && onPartClick?.('body')} />
      {/* Bell Rim */}
      <rect x="42" y="165" width="156" height="15" rx="7" fill={getF(parts, 'rim', '#F59E0B')} stroke="#1E293B" strokeWidth="4" className={cc} onClick={() => interactive && onPartClick?.('rim')} />
    </g>
  );
};
