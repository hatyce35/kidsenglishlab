import React from 'react';
import { ArtworkProps } from './artworkComponents';

const cursorClass = (interactive: boolean) =>
  interactive ? 'cursor-pointer hover:opacity-85 hover:stroke-amber-400 hover:stroke-[3px] transition-all' : '';

const getF = (parts: Record<string, string>, key: string, fallback: string) => parts[key] || fallback;

// 91. 🥪 SANDWICH (8 Letters)
export const SandwichColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Top Bread Slice */}
      <path d="M 40 90 L 120 45 L 200 90 L 120 115 Z" fill={getF(parts, 'bread', '#FBBF24')} stroke="#1E293B" strokeWidth="4.5" strokeLinejoin="round" className={cc} onClick={() => interactive && onPartClick?.('bread')} />
      {/* Lettuce */}
      <path d="M 35 105 Q 60 120 90 105 Q 120 125 150 105 Q 180 120 205 105" stroke={getF(parts, 'lettuce', '#22C55E')} strokeWidth="10" strokeLinecap="round" fill="none" className={cc} onClick={() => interactive && onPartClick?.('lettuce')} />
      {/* Tomato Slice */}
      <rect x="50" y="115" width="140" height="15" rx="5" fill={getF(parts, 'tomato', '#EF4444')} stroke="#1E293B" strokeWidth="3.5" className={cc} onClick={() => interactive && onPartClick?.('tomato')} />
      {/* Cheese Slice */}
      <polygon points="45,130 200,130 170,145 70,145" fill={getF(parts, 'cheese', '#FDE047')} stroke="#1E293B" strokeWidth="3" />
      {/* Bottom Bread Slice */}
      <path d="M 40 145 L 120 120 L 200 145 L 120 190 Z" fill={getF(parts, 'bread', '#D97706')} stroke="#1E293B" strokeWidth="4.5" strokeLinejoin="round" className={cc} onClick={() => interactive && onPartClick?.('bread')} />
      {/* Olive on Toothpick */}
      <line x1="120" y1="25" x2="120" y2="70" stroke="#78350F" strokeWidth="4" strokeLinecap="round" />
      <circle cx="120" cy="30" r="10" fill="#15803D" stroke="#1E293B" strokeWidth="2.5" />
      <circle cx="120" cy="30" r="3" fill="#EF4444" />
    </g>
  );
};

// 92.  umbrella / submarine / crocodile
// 92. 🐊 CROCODILE (9 Letters)
export const CrocodileColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Tail with scutes */}
      <polygon points="150,130 215,100 170,160" fill={getF(parts, 'body', '#15803D')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('body')} />
      {/* Body */}
      <ellipse cx="120" cy="140" rx="60" ry="38" fill={getF(parts, 'body', '#16A34A')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('body')} />
      {/* Long Snout */}
      <polygon points="120,115 30,135 30,155 120,165" fill={getF(parts, 'body', '#16A34A')} stroke="#1E293B" strokeWidth="4.5" strokeLinejoin="round" className={cc} onClick={() => interactive && onPartClick?.('body')} />
      {/* Sharp Teeth */}
      <polygon points="45,138 52,148 60,138" fill="#FFFFFF" />
      <polygon points="70,138 78,148 85,138" fill="#FFFFFF" />
      {/* Big Eyes on Top */}
      <circle cx="105" cy="105" r="12" fill={getF(parts, 'body', '#16A34A')} stroke="#1E293B" strokeWidth="3.5" />
      <circle cx="105" cy="105" r="7" fill="#FBBF24" />
      <circle cx="105" cy="105" r="3.5" fill="#1E293B" />
      {/* Nostril */}
      <circle cx="42" cy="132" r="3" fill="#1E293B" />
      {/* Stubby Legs */}
      <ellipse cx="85" cy="175" rx="14" ry="8" fill="#15803D" stroke="#1E293B" strokeWidth="3.5" />
      <ellipse cx="145" cy="175" rx="14" ry="8" fill="#15803D" stroke="#1E293B" strokeWidth="3.5" />
    </g>
  );
};

// 93. ☂️ UMBRELLA (8 Letters)
export const UmbrellaColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Canopy Dome */}
      <path d="M 40 130 C 40 50, 200 50, 200 130 Q 173 115 146 130 Q 120 115 94 130 Q 67 115 40 130 Z" fill={getF(parts, 'canopy', '#EC4899')} stroke="#1E293B" strokeWidth="5" className={cc} onClick={() => interactive && onPartClick?.('canopy')} />
      {/* Top Tip */}
      <line x1="120" y1="50" x2="120" y2="35" stroke="#1E293B" strokeWidth="5" strokeLinecap="round" />
      {/* Shaft */}
      <line x1="120" y1="125" x2="120" y2="195" stroke="#64748B" strokeWidth="5" strokeLinecap="round" />
      {/* Hook Handle */}
      <path d="M 120 195 C 120 220, 95 220, 95 200" stroke="#F59E0B" strokeWidth="6" strokeLinecap="round" fill="none" className={cc} onClick={() => interactive && onPartClick?.('handle')} />
      {/* Raindrops */}
      <path d="M 45 160 Q 40 175 45 180 Q 50 175 45 160" fill="#38BDF8" />
      <path d="M 195 160 Q 190 175 195 180 Q 200 175 195 160" fill="#38BDF8" />
    </g>
  );
};

// 94. 🦚 PEACOCK (7 Letters)
export const PeacockColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Fan Tail */}
      <path d="M 40 150 C 30 50, 210 50, 200 150 Z" fill={getF(parts, 'tail', '#059669')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('tail')} />
      {/* Feather Eyes */}
      <circle cx="70" cy="95" r="10" fill="#38BDF8" stroke="#1E293B" strokeWidth="2" />
      <circle cx="70" cy="95" r="5" fill="#FBBF24" />
      <circle cx="120" cy="70" r="12" fill="#38BDF8" stroke="#1E293B" strokeWidth="2" />
      <circle cx="120" cy="70" r="6" fill="#FBBF24" />
      <circle cx="170" cy="95" r="10" fill="#38BDF8" stroke="#1E293B" strokeWidth="2" />
      <circle cx="170" cy="95" r="5" fill="#FBBF24" />
      {/* Peacock Body */}
      <ellipse cx="120" cy="150" rx="28" ry="40" fill={getF(parts, 'body', '#1D4ED8')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('body')} />
      {/* Crest */}
      <line x1="120" y1="110" x2="110" y2="85" stroke="#1D4ED8" strokeWidth="3" />
      <circle cx="110" cy="85" r="4" fill="#38BDF8" />
      <line x1="120" y1="110" x2="130" y2="85" stroke="#1D4ED8" strokeWidth="3" />
      <circle cx="130" cy="85" r="4" fill="#38BDF8" />
      {/* Beak */}
      <polygon points="120,118 108,124 120,130" fill="#FBBF24" />
      {/* Eyes */}
      <circle cx="114" cy="115" r="3" fill="#FFFFFF" />
      <circle cx="126" cy="115" r="3" fill="#FFFFFF" />
    </g>
  );
};

// 95. 🦩 SUBMARINE (9 Letters)
export const SubmarineColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Periscope Tower */}
      <rect x="105" y="65" width="30" height="35" rx="6" fill={getF(parts, 'hull', '#FBBF24')} stroke="#1E293B" strokeWidth="4" />
      <path d="M 120 65 L 120 40 L 140 40" stroke="#1E293B" strokeWidth="5" strokeLinecap="round" fill="none" />
      {/* Submarine Main Hull */}
      <ellipse cx="120" cy="130" rx="80" ry="42" fill={getF(parts, 'hull', '#FBBF24')} stroke="#1E293B" strokeWidth="5" className={cc} onClick={() => interactive && onPartClick?.('hull')} />
      {/* Porthole Windows */}
      <circle cx="85" cy="130" r="14" fill={getF(parts, 'windows', '#38BDF8')} stroke="#1E293B" strokeWidth="3.5" className={cc} onClick={() => interactive && onPartClick?.('windows')} />
      <circle cx="120" cy="130" r="14" fill={getF(parts, 'windows', '#38BDF8')} stroke="#1E293B" strokeWidth="3.5" className={cc} onClick={() => interactive && onPartClick?.('windows')} />
      <circle cx="155" cy="130" r="14" fill={getF(parts, 'windows', '#38BDF8')} stroke="#1E293B" strokeWidth="3.5" className={cc} onClick={() => interactive && onPartClick?.('windows')} />
      {/* Propeller */}
      <polygon points="35,115 45,130 35,145" fill="#EF4444" stroke="#1E293B" strokeWidth="3" />
    </g>
  );
};

// 96. 🚁 HELICOPTER (10 Letters)
export const HelicopterColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Rotor Blades */}
      <line x1="30" y1="50" x2="210" y2="50" stroke="#1E293B" strokeWidth="6" strokeLinecap="round" />
      <rect x="115" y="50" width="10" height="20" fill="#64748B" stroke="#1E293B" strokeWidth="2" />
      {/* Tail Boom */}
      <rect x="140" y="105" width="65" height="15" rx="5" fill={getF(parts, 'cabin', '#3B82F6')} stroke="#1E293B" strokeWidth="4" />
      {/* Tail Rotor */}
      <line x1="205" y1="90" x2="205" y2="135" stroke="#EF4444" strokeWidth="4" strokeLinecap="round" />
      {/* Cabin Body */}
      <ellipse cx="100" cy="115" rx="50" ry="38" fill={getF(parts, 'cabin', '#3B82F6')} stroke="#1E293B" strokeWidth="5" className={cc} onClick={() => interactive && onPartClick?.('cabin')} />
      {/* Windshield */}
      <path d="M 60 115 C 60 90, 95 90, 110 95 L 110 135 L 65 135 Z" fill={getF(parts, 'window', '#BAE6FD')} stroke="#1E293B" strokeWidth="3.5" className={cc} onClick={() => interactive && onPartClick?.('window')} />
      {/* Landing Skids */}
      <line x1="75" y1="150" x2="75" y2="170" stroke="#1E293B" strokeWidth="4" />
      <line x1="125" y1="150" x2="125" y2="170" stroke="#1E293B" strokeWidth="4" />
      <line x1="50" y1="170" x2="150" y2="170" stroke="#1E293B" strokeWidth="5" strokeLinecap="round" />
    </g>
  );
};

// 97. 🍓 STRAWBERRY (10 Letters)
export const StrawberryColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Stem */}
      <path d="M 120 50 Q 115 25 130 20" stroke="#15803D" strokeWidth="5" strokeLinecap="round" fill="none" />
      {/* Strawberry Body */}
      <path d="M 120 70 C 60 70, 50 140, 120 220 C 190 140, 180 70, 120 70 Z" fill={getF(parts, 'berry', '#EF4444')} stroke="#1E293B" strokeWidth="5" className={cc} onClick={() => interactive && onPartClick?.('berry')} />
      {/* Calyx Leaves */}
      <g fill={getF(parts, 'leaves', '#22C55E')} stroke="#1E293B" strokeWidth="3.5" className={cc} onClick={() => interactive && onPartClick?.('leaves')}>
        <polygon points="120,70 85,55 100,75" />
        <polygon points="120,70 120,45 125,70" />
        <polygon points="120,70 155,55 140,75" />
      </g>
      {/* Seeds */}
      <ellipse cx="90" cy="110" rx="3" ry="5" fill="#FDE047" />
      <ellipse cx="120" cy="105" rx="3" ry="5" fill="#FDE047" />
      <ellipse cx="150" cy="110" rx="3" ry="5" fill="#FDE047" />
      <ellipse cx="105" cy="145" rx="3" ry="5" fill="#FDE047" />
      <ellipse cx="135" cy="145" rx="3" ry="5" fill="#FDE047" />
      <ellipse cx="120" cy="180" rx="3" ry="5" fill="#FDE047" />
    </g>
  );
};

// 98. 🍍 PINEAPPLE (9 Letters)
export const PineappleColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Spiky Crown Leaves */}
      <g fill={getF(parts, 'crown', '#16A34A')} stroke="#1E293B" strokeWidth="3.5" className={cc} onClick={() => interactive && onPartClick?.('crown')}>
        <polygon points="120,80 80,30 110,65" />
        <polygon points="120,80 120,20 130,65" />
        <polygon points="120,80 160,30 130,65" />
        <polygon points="120,80 95,45 110,75" />
        <polygon points="120,80 145,45 130,75" />
      </g>
      {/* Pineapple Oval */}
      <ellipse cx="120" cy="145" rx="55" ry="65" fill={getF(parts, 'fruit', '#FBBF24')} stroke="#1E293B" strokeWidth="5" className={cc} onClick={() => interactive && onPartClick?.('fruit')} />
      {/* Crosshatch Pattern */}
      <line x1="80" y1="110" x2="160" y2="180" stroke="#D97706" strokeWidth="3" strokeLinecap="round" />
      <line x1="160" y1="110" x2="80" y2="180" stroke="#D97706" strokeWidth="3" strokeLinecap="round" />
      <line x1="90" y1="95" x2="150" y2="195" stroke="#D97706" strokeWidth="3" strokeLinecap="round" />
      <line x1="150" y1="95" x2="90" y2="195" stroke="#D97706" strokeWidth="3" strokeLinecap="round" />
    </g>
  );
};

// 99. 🚂 LOCOMOTIVE (10 Letters)
export const LocomotiveColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Smoke */}
      <circle cx="75" cy="35" r="10" fill="#E2E8F0" opacity="0.8" />
      <circle cx="65" cy="20" r="14" fill="#E2E8F0" opacity="0.8" />
      {/* Chimney */}
      <polygon points="70,80 60,50 90,50 80,80" fill="#1E293B" />
      {/* Cabin */}
      <rect x="130" y="70" width="65" height="90" rx="8" fill={getF(parts, 'body', '#EF4444')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('body')} />
      <rect x="145" y="85" width="35" height="30" rx="4" fill="#BAE6FD" stroke="#1E293B" strokeWidth="3" />
      {/* Boiler */}
      <rect x="45" y="80" width="95" height="80" rx="8" fill={getF(parts, 'boiler', '#1D4ED8')} stroke="#1E293B" strokeWidth="4.5" className={cc} onClick={() => interactive && onPartClick?.('boiler')} />
      {/* Cowcatcher */}
      <polygon points="45,150 20,170 45,170" fill="#FBBF24" stroke="#1E293B" strokeWidth="3" />
      {/* Wheels */}
      <circle cx="65" cy="170" r="18" fill="#1E293B" stroke="#64748B" strokeWidth="3" />
      <circle cx="105" cy="170" r="18" fill="#1E293B" stroke="#64748B" strokeWidth="3" />
      <circle cx="160" cy="165" r="24" fill="#1E293B" stroke="#64748B" strokeWidth="4" />
      <circle cx="160" cy="165" r="8" fill="#CBD5E1" />
    </g>
  );
};

// 100. 🎆 FIREWORKS (9 Letters)
export const FireworksColorableSVG: React.FC<ArtworkProps> = ({ parts, onPartClick, interactive = true }) => {
  const cc = cursorClass(interactive);
  return (
    <g transform="translate(10, 10)">
      {/* Center Sparkle */}
      <circle cx="120" cy="120" r="16" fill={getF(parts, 'core', '#FBBF24')} stroke="#1E293B" strokeWidth="3" className={cc} onClick={() => interactive && onPartClick?.('core')} />
      {/* Bursts & Rays */}
      <g stroke={getF(parts, 'sparks', '#EC4899')} strokeWidth="5" strokeLinecap="round" className={cc} onClick={() => interactive && onPartClick?.('sparks')}>
        <line x1="120" y1="90" x2="120" y2="40" />
        <line x1="120" y1="150" x2="120" y2="200" />
        <line x1="90" y1="120" x2="40" y2="120" />
        <line x1="150" y1="120" x2="200" y2="120" />
        <line x1="95" y1="95" x2="60" y2="60" />
        <line x1="145" y1="95" x2="180" y2="60" />
        <line x1="95" y1="145" x2="60" y2="180" />
        <line x1="145" y1="145" x2="180" y2="180" />
      </g>
      {/* Spark Stars */}
      <circle cx="120" cy="35" r="6" fill="#38BDF8" />
      <circle cx="120" cy="205" r="6" fill="#38BDF8" />
      <circle cx="35" cy="120" r="6" fill="#FBBF24" />
      <circle cx="205" cy="120" r="6" fill="#FBBF24" />
      <circle cx="55" cy="55" r="6" fill="#22C55E" />
      <circle cx="185" cy="55" r="6" fill="#22C55E" />
      <circle cx="55" cy="185" r="6" fill="#A855F7" />
      <circle cx="185" cy="185" r="6" fill="#A855F7" />
    </g>
  );
};
